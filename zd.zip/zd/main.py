import os
import sys
from random import choice, random, randrange


import pygame

FPS = 60


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    # если файл не существует, то выходим
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    return image


if __name__ == '__main__':
    pygame.init()
    pygame.display.set_caption('image')
    size = width, height = 600, 300
    screen = pygame.display.set_mode(size)
    
    sp = []
    
    clock = pygame.time.Clock()
    running = True
    all_sprites = pygame.sprite.Group()

    end_image = pygame.sprite.Sprite(all_sprites)
    end_image.image = load_image('pngend.png')
    end_image.rect = end_image.image.get_rect()
    end_image.rect.x, end_image.rect.y = -600, 0

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        
        if end_image.rect.x < 0:
            clock = pygame.time.Clock()
            clock.tick(FPS)
            end_image.rect.x += 200 / FPS
        screen.fill((0, 0, 255))
        all_sprites.draw(screen)
        pygame.display.flip()

    pygame.quit()

