from flask import Flask, request, render_template
import os

app = Flask(__name__)

# Указываем путь для сохранения загруженного файла
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', 'img')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        # Получаем загруженный файл из запроса
        file = request.files['photo']
        # Сохраняем файл на сервере
        filename = file.filename
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        # Перенаправляем на ту же страницу для отображения фотографии
        return render_template('upload.html', filename=filename)
    # Отображаем форму для загрузки файла
    return render_template('upload.html')


if __name__ == '__main__':
    app.run(debug=True, port=8080)
