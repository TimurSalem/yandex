from flask import Flask, render_template
import random
import json

app = Flask(__name__)


@app.route('/')
def member():
    with open('templates/crew.json') as f:
        crew_data = json.load(f)
    member = random.choice(crew_data['crew_members'])
    return render_template('crew.html', member=member)


if __name__ == '__main__':
    app.run(debug=True, port=12000)
